import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import Breadcrumb from '@/components/Breadcrumb'
import {
  CATEGORY_META, Category, Severity,
  getCodesByCategory, getCategoryStats, catLabel,
} from '@/lib/codes-db'

const BASE = process.env.NEXT_PUBLIC_BASE_URL ?? 'https://autocodefix.com'

const SEV_HEX: Record<Severity, string> = { high: '#FF1744', med: '#FFC107', low: '#00C853' }
const SEV_LABEL: Record<Severity, string> = { high: 'Critical', med: 'Moderate', low: 'Minor' }

const ALL_CATS = Object.keys(CATEGORY_META) as Category[]

export function generateStaticParams() {
  return ALL_CATS.map(slug => ({ slug }))
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params
  if (!ALL_CATS.includes(slug as Category)) return {}

  const cat = slug as Category
  const meta = CATEGORY_META[cat]
  const stats = getCategoryStats(cat)
  const title = `${meta.label} OBD2 Codes — AUTO CODE FIX`
  const description = `Browse ${stats.total} ${meta.label} OBD2 diagnostic trouble codes with causes, symptoms, and repair guides. Includes ${stats.high} critical codes and ${stats.diy} DIY-fixable faults.`

  return {
    title,
    description,
    alternates: { canonical: `${BASE}/category/${cat}` },
    openGraph: { title, description, url: `${BASE}/category/${cat}` },
  }
}

export default async function CategoryPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params

  if (!ALL_CATS.includes(slug as Category)) notFound()

  const cat = slug as Category
  const meta = CATEGORY_META[cat]
  const codes = getCodesByCategory(cat)
  const stats = getCategoryStats(cat)

  // Breadcrumb JSON-LD
  const breadcrumbSchema = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: [
      { '@type': 'ListItem', position: 1, name: 'Home', item: BASE },
      { '@type': 'ListItem', position: 2, name: 'Categories', item: `${BASE}/category` },
      { '@type': 'ListItem', position: 3, name: meta.label, item: `${BASE}/category/${cat}` },
    ],
  }

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbSchema) }} />

      <Header />

      <Breadcrumb
        items={[
          { label: 'Home', href: '/' },
          { label: 'Categories', href: '/category' },
          { label: meta.label },
        ]}
      />

      {/* Category Hero */}
      <div style={{
        background: 'var(--dark2)',
        borderBottom: '1px solid var(--border)',
        padding: '3rem 2rem 2.5rem',
        position: 'relative',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: -80, right: -80,
          width: 350, height: 350,
          background: 'radial-gradient(circle, rgba(255,87,34,0.08) 0%, transparent 70%)',
          pointerEvents: 'none',
        }} />

        <div style={{ maxWidth: 1000, margin: '0 auto' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: '1.25rem', flexWrap: 'wrap' }}>
            <div style={{
              fontSize: '3rem', lineHeight: 1,
              background: 'rgba(255,87,34,0.1)',
              border: '1px solid rgba(255,87,34,0.25)',
              borderRadius: 14, padding: '0.75rem',
            }}>
              {meta.icon}
            </div>
            <div>
              <div style={{ fontSize: '0.72rem', color: 'var(--orange)', textTransform: 'uppercase', letterSpacing: 2, marginBottom: 4 }}>
                Category
              </div>
              <h1 style={{
                fontFamily: 'var(--font-bebas)',
                fontSize: 'clamp(2.5rem,6vw,4.5rem)',
                letterSpacing: 4, color: 'var(--text)', lineHeight: 1,
              }}>
                {meta.label} <span style={{ color: 'var(--orange)' }}>CODES</span>
              </h1>
            </div>
          </div>

          {/* Stats strip */}
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            {[
              { label: 'Total Codes', value: stats.total, color: 'var(--orange)' },
              { label: 'Critical', value: stats.high, color: SEV_HEX.high },
              { label: 'Moderate', value: stats.med, color: SEV_HEX.med },
              { label: 'Minor', value: stats.low, color: SEV_HEX.low },
              { label: 'DIY Friendly', value: stats.diy, color: 'var(--green)' },
            ].map(({ label, value, color }) => (
              <div key={label} style={{
                background: 'var(--card)',
                border: '1px solid var(--border)',
                borderRadius: 10, padding: '0.6rem 1.1rem',
              }}>
                <span style={{ display: 'block', fontSize: '0.62rem', color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: 1 }}>{label}</span>
                <span style={{ display: 'block', fontFamily: 'var(--font-bebas)', fontSize: '1.5rem', color, letterSpacing: 1 }}>{value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Code list */}
      <div style={{ maxWidth: 1000, margin: '0 auto', padding: '2.5rem 2rem 5rem' }}>

        {/* Severity quick-jump */}
        <div style={{ display: 'flex', gap: 8, marginBottom: '1.5rem', flexWrap: 'wrap' }}>
          <span style={{ fontSize: '0.8rem', color: 'var(--muted)', alignSelf: 'center' }}>Filter:</span>
          {(['high', 'med', 'low'] as Severity[]).map(sev => (
            <a
              key={sev}
              href={`#sev-${sev}`}
              style={{
                background: `${SEV_HEX[sev]}18`,
                border: `1px solid ${SEV_HEX[sev]}55`,
                borderRadius: 20, fontSize: '0.75rem',
                color: SEV_HEX[sev], padding: '5px 14px',
                textDecoration: 'none', fontWeight: 600,
              }}
            >
              {SEV_LABEL[sev]} ({sev === 'high' ? stats.high : sev === 'med' ? stats.med : stats.low})
            </a>
          ))}
        </div>

        {(['high', 'med', 'low'] as Severity[]).map(sev => {
          const sevCodes = codes.filter(c => c.sev === sev)
          if (sevCodes.length === 0) return null
          return (
            <div key={sev} id={`sev-${sev}`} style={{ marginBottom: '3rem' }}>
              {/* Section header */}
              <div style={{
                display: 'flex', alignItems: 'center', gap: 10,
                marginBottom: '1rem',
                paddingBottom: '0.75rem',
                borderBottom: `2px solid ${SEV_HEX[sev]}44`,
              }}>
                <div style={{ width: 10, height: 10, borderRadius: '50%', background: SEV_HEX[sev], flexShrink: 0 }} />
                <h2 style={{
                  fontFamily: 'var(--font-bebas)',
                  fontSize: '1.4rem', letterSpacing: 2,
                  color: SEV_HEX[sev], margin: 0,
                }}>
                  {SEV_LABEL[sev]}
                </h2>
                <span style={{ fontSize: '0.78rem', color: 'var(--muted)' }}>
                  {sevCodes.length} code{sevCodes.length !== 1 ? 's' : ''}
                </span>
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 14 }}>
                {sevCodes.map(c => (
                  <Link
                    key={c.code}
                    href={`/${c.code.toLowerCase()}`}
                    style={{
                      background: 'var(--card)',
                      border: '1.5px solid var(--border)',
                      borderRadius: 'var(--radius)',
                      padding: '1.1rem 1.1rem 1.1rem 1.3rem',
                      textDecoration: 'none',
                      display: 'block',
                      position: 'relative',
                      overflow: 'hidden',
                      transition: 'border-color .18s, transform .18s',
                    }}
                    onMouseEnter={e => {
                      const el = e.currentTarget as HTMLElement
                      el.style.borderColor = SEV_HEX[sev]
                      el.style.transform = 'translateY(-2px)'
                    }}
                    onMouseLeave={e => {
                      const el = e.currentTarget as HTMLElement
                      el.style.borderColor = 'var(--border)'
                      el.style.transform = 'translateY(0)'
                    }}
                  >
                    <span style={{
                      position: 'absolute', top: 0, left: 0,
                      width: 3, height: '100%',
                      background: SEV_HEX[sev],
                    }} />

                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 6 }}>
                      <span style={{
                        fontFamily: 'var(--font-bebas)',
                        fontSize: '1.4rem', letterSpacing: 2,
                        color: 'var(--orange)',
                      }}>
                        {c.code}
                      </span>
                      {c.diy && (
                        <span style={{
                          fontSize: '0.62rem', fontWeight: 700,
                          background: 'rgba(0,200,83,.12)', color: 'var(--green)',
                          border: '1px solid rgba(0,200,83,.3)',
                          borderRadius: 20, padding: '2px 8px',
                          textTransform: 'uppercase', letterSpacing: 0.5,
                        }}>DIY</span>
                      )}
                    </div>

                    <div style={{ fontSize: '0.85rem', fontWeight: 600, color: 'var(--text)', marginBottom: 5, lineHeight: 1.35 }}>
                      {c.name}
                    </div>
                    <div style={{ fontSize: '0.77rem', color: 'var(--muted)', lineHeight: 1.5 }}>
                      {(c.desc ?? c.causes[0]).slice(0, 90)}{((c.desc ?? c.causes[0]).length > 90) ? '…' : ''}
                    </div>

                    <div style={{
                      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
                      marginTop: '0.75rem', paddingTop: '0.75rem',
                      borderTop: '1px solid var(--border)',
                    }}>
                      <span style={{ fontSize: '0.72rem', color: 'var(--orange)', fontWeight: 600 }}>
                        {c.avg_cost}
                      </span>
                      <span style={{ fontSize: '0.75rem', color: 'var(--orange)', fontWeight: 600 }}>
                        View →
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )
        })}
      </div>

      <Footer />
    </>
  )
}
