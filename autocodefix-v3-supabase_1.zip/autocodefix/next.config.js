/** @type {import('next').NextConfig} */
const nextConfig = {
  // Generate static pages for all known codes at build time
  output: 'standalone',
  // Allow Anthropic API calls from server-side routes
  experimental: {
    serverComponentsExternalPackages: ['@anthropic-ai/sdk'],
  },
}

module.exports = nextConfig
