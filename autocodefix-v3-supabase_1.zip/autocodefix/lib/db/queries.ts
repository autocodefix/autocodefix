/**
 * AUTO CODE FIX — Database query layer
 *
 * All DB access goes through this file.
 * Server Components and API routes import from here — never from client.ts directly.
 *
 * Fallback: if SUPABASE_URL is not set (local dev without DB), it falls back
 * to the static codes-db.ts so the site always works.
 */

import type { OBDCode, Category, Severity } from '@/lib/codes-db'

// ── Helpers ──────────────────────────────────────────────────────────────────

function isSupabaseConfigured(): boolean {
  return Boolean(process.env.SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY)
}

/** Map a Supabase row → OBDCode shape used by the rest of the app */
function rowToCode(row: {
  code: string
  name: string
  cat: string
  sev: string
  description: string | null
  causes: string[]
  symptoms: string[]
  solutions: string[]
  diy: boolean
  avg_cost: string
  tip: string | null
  img_url?: string | null
  video_url?: string | null
}): OBDCode {
  return {
    code:      row.code,
    name:      row.name,
    cat:       row.cat as Category,
    sev:       row.sev as Severity,
    desc:      row.description ?? undefined,
    causes:    row.causes,
    symptoms:  row.symptoms,
    solutions: row.solutions,
    diy:       row.diy,
    avg_cost:  row.avg_cost,
    tip:       row.tip ?? undefined,
    img:       row.img_url ?? undefined,
    video:     row.video_url ?? undefined,
  }
}

// ── getCode ───────────────────────────────────────────────────────────────────

/**
 * Look up a single OBD code by its code string (case-insensitive).
 * Used by: /[code]/page.tsx
 */
export async function dbGetCode(code: string): Promise<OBDCode | null> {
  if (!isSupabaseConfigured()) {
    const { getCode } = await import('@/lib/codes-db')
    return getCode(code) ?? null
  }

  const { supabase } = await import('./client')
  const { data, error } = await supabase
    .from('obd_codes')
    .select('*')
    .ilike('code', code)
    .single()

  if (error || !data) return null
  return rowToCode(data)
}

// ── getAllCodes ───────────────────────────────────────────────────────────────

/**
 * Return ALL codes — used for static param generation and the homepage list.
 * Results are cached by Next.js (static generation) at build time.
 */
export async function dbGetAllCodes(): Promise<OBDCode[]> {
  if (!isSupabaseConfigured()) {
    const { CODES } = await import('@/lib/codes-db')
    return CODES
  }

  const { supabase } = await import('./client')
  // Supabase max default is 1000 rows — use range pagination for large datasets
  const PAGE = 1000
  let from = 0
  const all: OBDCode[] = []

  while (true) {
    const { data, error } = await supabase
      .from('obd_codes')
      .select('*')
      .order('code')
      .range(from, from + PAGE - 1)

    if (error || !data || data.length === 0) break
    all.push(...data.map(rowToCode))
    if (data.length < PAGE) break
    from += PAGE
  }

  return all
}

// ── getCodesByCategory ────────────────────────────────────────────────────────

/**
 * Return all codes for a given category, sorted by severity then code.
 * Used by: /category/[cat]/page.tsx
 */
export async function dbGetCodesByCategory(cat: Category): Promise<OBDCode[]> {
  if (!isSupabaseConfigured()) {
    const { CODES } = await import('@/lib/codes-db')
    return CODES.filter(c => c.cat === cat)
  }

  const { supabase } = await import('./client')
  const { data, error } = await supabase
    .from('obd_codes')
    .select('*')
    .eq('cat', cat)
    .order('sev')
    .order('code')

  if (error || !data) return []
  return data.map(rowToCode)
}

// ── getAllSlugs ───────────────────────────────────────────────────────────────

/**
 * Return lowercase code slugs for generateStaticParams.
 */
export async function dbGetAllSlugs(): Promise<string[]> {
  if (!isSupabaseConfigured()) {
    const { getAllSlugs } = await import('@/lib/codes-db')
    return getAllSlugs()
  }

  const { supabase } = await import('./client')
  const { data, error } = await supabase
    .from('obd_codes')
    .select('code')
    .order('code')

  if (error || !data) return []
  return data.map(r => r.code.toLowerCase())
}

// ── searchCodes ───────────────────────────────────────────────────────────────

export interface SearchResult {
  code:  string
  name:  string
  cat:   Category
  sev:   Severity
  desc?: string
}

/**
 * Full-text + fuzzy code search.
 * Uses the Postgres search_obd_codes() function when DB is available,
 * falls back to the in-memory searchCodes() otherwise.
 */
export async function dbSearchCodes(query: string, limit = 8): Promise<SearchResult[]> {
  if (!isSupabaseConfigured()) {
    const { searchCodes } = await import('@/lib/codes-db')
    return searchCodes(query, limit)
  }

  const { supabase } = await import('./client')
  const { data, error } = await supabase.rpc('search_obd_codes', {
    query,
    result_limit: limit,
  })

  if (error || !data) return []
  return data.map((r: { code: string; name: string; cat: string; sev: string; description: string | null }) => ({
    code: r.code,
    name: r.name,
    cat:  r.cat as Category,
    sev:  r.sev as Severity,
    desc: r.description ?? undefined,
  }))
}

// ── getRelatedCodes ───────────────────────────────────────────────────────────

/**
 * Related codes = same category, sorted by code prefix proximity.
 * Simple approach that works well for both DB and static modes.
 */
export async function dbGetRelatedCodes(code: OBDCode, limit = 6): Promise<OBDCode[]> {
  if (!isSupabaseConfigured()) {
    const { getRelatedCodes } = await import('@/lib/codes-db')
    return getRelatedCodes(code, limit)
  }

  const { supabase } = await import('./client')
  const { data, error } = await supabase
    .from('obd_codes')
    .select('*')
    .eq('cat', code.cat)
    .neq('code', code.code)
    .order('sev')
    .limit(limit * 2)  // fetch more, then pick closest by code number

  if (error || !data || data.length === 0) return []

  // Sort by numeric proximity to the current code
  const num = parseInt(code.code.slice(1), 10)
  return data
    .sort((a, b) => {
      const da = Math.abs(parseInt(a.code.slice(1), 10) - num)
      const db = Math.abs(parseInt(b.code.slice(1), 10) - num)
      return da - db
    })
    .slice(0, limit)
    .map(rowToCode)
}

// ── getCategoryStats ──────────────────────────────────────────────────────────

export interface CategoryStats {
  total: number
  high:  number
  med:   number
  low:   number
  diy:   number
}

/**
 * Returns stats for a single category.
 * Uses the category_stats materialized view when DB is configured.
 */
export async function dbGetCategoryStats(cat: Category): Promise<CategoryStats> {
  if (!isSupabaseConfigured()) {
    const { getCategoryStats } = await import('@/lib/codes-db')
    return getCategoryStats(cat)
  }

  const { supabase } = await import('./client')
  const { data, error } = await supabase
    .from('category_stats')
    .select('*')
    .eq('cat', cat)
    .single()

  if (error || !data) return { total: 0, high: 0, med: 0, low: 0, diy: 0 }
  return {
    total: Number(data.total),
    high:  Number(data.high_count),
    med:   Number(data.med_count),
    low:   Number(data.low_count),
    diy:   Number(data.diy_count),
  }
}

/**
 * Returns stats for ALL categories in one query.
 * Used by the homepage/categories index page.
 */
export async function dbGetAllCategoryStats(): Promise<Record<Category, CategoryStats>> {
  if (!isSupabaseConfigured()) {
    const { CATEGORY_META, getCategoryStats } = await import('@/lib/codes-db')
    const cats = Object.keys(CATEGORY_META) as Category[]
    const result: Partial<Record<Category, CategoryStats>> = {}
    for (const cat of cats) result[cat] = getCategoryStats(cat)
    return result as Record<Category, CategoryStats>
  }

  const { supabase } = await import('./client')
  const { data, error } = await supabase.from('category_stats').select('*')

  const fallback: CategoryStats = { total: 0, high: 0, med: 0, low: 0, diy: 0 }
  if (error || !data) {
    const { CATEGORY_META } = await import('@/lib/codes-db')
    return Object.fromEntries(
      (Object.keys(CATEGORY_META) as Category[]).map(c => [c, fallback])
    ) as Record<Category, CategoryStats>
  }

  return Object.fromEntries(
    data.map(r => [r.cat, {
      total: Number(r.total),
      high:  Number(r.high_count),
      med:   Number(r.med_count),
      low:   Number(r.low_count),
      diy:   Number(r.diy_count),
    }])
  ) as Record<Category, CategoryStats>
}
