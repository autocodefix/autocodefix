/**
 * AUTO CODE FIX — Supabase TypeScript types
 *
 * These were generated to match 001_initial_schema.sql exactly.
 * To regenerate from a live project:
 *   npx supabase gen types typescript --project-id YOUR_PROJECT_ID > lib/db/database.types.ts
 */

export type OdbCategory =
  | 'engine' | 'fuel' | 'emissions' | 'transmission'
  | 'ignition' | 'abs' | 'airbag' | 'hvac'
  | 'electrical' | 'network' | 'sensors' | 'exhaust'

export type OdbSeverity = 'high' | 'med' | 'low'

export interface Database {
  public: {
    Tables: {
      obd_codes: {
        Row: {
          id:          number
          code:        string
          name:        string
          cat:         OdbCategory
          sev:         OdbSeverity
          description: string | null
          causes:      string[]
          symptoms:    string[]
          solutions:   string[]
          diy:         boolean
          avg_cost:    string
          tip:         string | null
          img_url:     string | null
          video_url:   string | null
          search_vec:  string | null   // tsvector — opaque in TS
          created_at:  string
          updated_at:  string
        }
        Insert: Omit<Database['public']['Tables']['obd_codes']['Row'], 'id' | 'search_vec' | 'created_at' | 'updated_at'>
        Update: Partial<Database['public']['Tables']['obd_codes']['Insert']>
      }
    }
    Views: {
      category_stats: {
        Row: {
          cat:        OdbCategory
          total:      number
          high_count: number
          med_count:  number
          low_count:  number
          diy_count:  number
        }
      }
    }
    Functions: {
      search_obd_codes: {
        Args:    { query: string; result_limit?: number }
        Returns: Array<{
          code:        string
          name:        string
          cat:         OdbCategory
          sev:         OdbSeverity
          description: string | null
          rank:        number
        }>
      }
      refresh_category_stats: {
        Args:    Record<string, never>
        Returns: void
      }
    }
  }
}
