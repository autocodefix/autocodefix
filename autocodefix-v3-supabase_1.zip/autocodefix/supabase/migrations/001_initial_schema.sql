-- ============================================================
-- AUTO CODE FIX — Supabase Schema
-- Run this in: Supabase Dashboard → SQL Editor
-- ============================================================

-- Enable pg_trgm for fast full-text LIKE search
create extension if not exists pg_trgm;

-- ── Enum types ──────────────────────────────────────────────
create type obd_category as enum (
  'engine','fuel','emissions','transmission',
  'ignition','abs','airbag','hvac',
  'electrical','network','sensors','exhaust'
);

create type obd_severity as enum ('high','med','low');

-- ── Main codes table ────────────────────────────────────────
create table if not exists obd_codes (
  id          bigint generated always as identity primary key,
  code        text        not null unique,          -- e.g. "P0300"
  name        text        not null,                 -- "Random/Multiple Cylinder Misfire"
  cat         obd_category not null,
  sev         obd_severity not null,
  description text,
  causes      text[]      not null default '{}',
  symptoms    text[]      not null default '{}',
  solutions   text[]      not null default '{}',
  diy         boolean     not null default true,
  avg_cost    text        not null default '$0–$0',
  tip         text,
  img_url     text,
  video_url   text,

  -- Full-text search vector (auto-maintained by trigger)
  search_vec  tsvector,

  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ── Search vector trigger ───────────────────────────────────
create or replace function obd_codes_search_vec_update()
returns trigger language plpgsql as $$
begin
  new.search_vec :=
    setweight(to_tsvector('english', coalesce(new.code, '')), 'A') ||
    setweight(to_tsvector('english', coalesce(new.name, '')), 'A') ||
    setweight(to_tsvector('english', coalesce(new.description, '')), 'B') ||
    setweight(to_tsvector('english', array_to_string(new.causes, ' ')), 'C') ||
    setweight(to_tsvector('english', array_to_string(new.symptoms, ' ')), 'C') ||
    setweight(to_tsvector('english', array_to_string(new.solutions, ' ')), 'D');
  return new;
end;
$$;

create trigger obd_codes_search_vec_trigger
before insert or update on obd_codes
for each row execute function obd_codes_search_vec_update();

-- ── updated_at trigger ──────────────────────────────────────
create or replace function set_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;

create trigger obd_codes_updated_at
before update on obd_codes
for each row execute function set_updated_at();

-- ── Indexes ─────────────────────────────────────────────────
-- Fast exact lookup (the most common query)
create unique index obd_codes_code_upper_idx on obd_codes (upper(code));

-- Fast category browsing
create index obd_codes_cat_idx   on obd_codes (cat);
create index obd_codes_sev_idx   on obd_codes (sev);
create index obd_codes_diy_idx   on obd_codes (diy);

-- Full-text search
create index obd_codes_search_vec_idx on obd_codes using gin(search_vec);

-- Trigram index for fast ILIKE autocomplete on code column
create index obd_codes_code_trgm_idx on obd_codes using gin(code gin_trgm_ops);
create index obd_codes_name_trgm_idx on obd_codes using gin(name gin_trgm_ops);

-- ── Row Level Security (public read, no public write) ───────
alter table obd_codes enable row level security;

-- Anyone can read codes
create policy "Public read access"
  on obd_codes for select
  using (true);

-- Only service_role (your server) can insert/update/delete
create policy "Service role write access"
  on obd_codes for all
  using (auth.role() = 'service_role');

-- ── Helper: search function ─────────────────────────────────
-- Returns scored results for the API — avoids N+1 in JS
create or replace function search_obd_codes(
  query       text,
  result_limit int default 8
)
returns table (
  code        text,
  name        text,
  cat         obd_category,
  sev         obd_severity,
  description text,
  rank        real
)
language sql stable as $$
  select
    c.code,
    c.name,
    c.cat,
    c.sev,
    c.description,
    ts_rank(c.search_vec, websearch_to_tsquery('english', query)) +
    -- Boost exact prefix match on code
    case when upper(c.code) like upper(query) || '%' then 0.5 else 0 end +
    -- Boost exact code match
    case when upper(c.code) = upper(query) then 1.0 else 0 end
    as rank
  from obd_codes c
  where
    c.search_vec @@ websearch_to_tsquery('english', query)
    or upper(c.code) like upper(query) || '%'
    or c.name ilike '%' || query || '%'
  order by rank desc
  limit result_limit;
$$;

-- ── Materialized view: category stats ──────────────────────
create materialized view category_stats as
select
  cat,
  count(*)                              as total,
  count(*) filter (where sev = 'high')  as high_count,
  count(*) filter (where sev = 'med')   as med_count,
  count(*) filter (where sev = 'low')   as low_count,
  count(*) filter (where diy = true)    as diy_count
from obd_codes
group by cat;

create unique index category_stats_cat_idx on category_stats (cat);

-- Refresh the materialized view after bulk inserts:
-- select refresh_category_stats();
create or replace function refresh_category_stats()
returns void language sql as $$
  refresh materialized view concurrently category_stats;
$$;
